// Sencepcja


var czas1 = new Date();
const tab = new Array(100);
let choose_number = Math.floor(Math.random() * 100);

var yes = new Audio("assets/audio/yes.mp3");
var no = new Audio("assets/audio/no.mp3");
var lost = new Audio("assets/audio/lost.mp3");
var wygrana = new Audio("assets/audio/Jeszcze_jak.mp3");

tab[0] = "Kula u nogi";
tab[1] = "Jabłko niezgody";
tab[2] = "Pięta achillesa";
tab[3] = "złote serce";
tab[4] = "Czarna owca";
tab[5] = "Dziesiąta woda po kisielu";
tab[6] = "Świecic oczyma";
tab[7] = "Sam jak palec";
tab[8] = "syzyfowa praca";
tab[9] = "puszka pandory";
tab[10] = "piłka nożna";
tab[11] = "piłka ręczna";
tab[12] = "koszykówka";
tab[13] = "Badminton";
tab[14] = "bilard";
tab[15] = "tenis";
tab[16] = "golf";
tab[17] = "łyżwiarstwo";
tab[18] = "kolarstwo";
tab[19] = "łucznictwo";
tab[20] = "Tygrys";
tab[21] = "Żubr";
tab[22] = "Chomik";
tab[23] = "Niedźwiedź";
tab[24] = "Świnka Morska";
tab[25] = "Baran";
tab[26] = "Owca";
tab[27] = "Rekin";
tab[28] = "Pingwin";
tab[29] = "Wiewiórka";
tab[30] = "Adidas";
tab[31] = "Nike";
tab[32] = "Calvin Klein";
tab[33] = "Tommy Hilfiger";
tab[34] = "Ralph Lauren";
tab[35] = "The North Face";
tab[36] = "Reebok";
tab[37] = "Puma";
tab[38] = "Vans";
tab[39] = "Carhartt";
tab[40] = "Volkswagen";
tab[41] = "Audi";
tab[42] = "Fiat";
tab[43] = "Ford";
tab[44] = "SAAB";
tab[45] = "Renault";
tab[46] = "Mercedes";
tab[47] = "Mitsubishi";
tab[48] = "Bugatti";
tab[49] = "BMW";
tab[50] = "Razer";
tab[51] = "Asus";
tab[52] = "Genesis";
tab[53] = "Bloody";
tab[54] = "Lenovo";
tab[55] = "Huawei";
tab[56] = "Samsung";
tab[57] = "Intel";
tab[58] = "MSI";
tab[59] = "PlayStation";
tab[60] = "League of Legends";
tab[61] = "Minecraft";
tab[62] = "Terraria";
tab[63] = "Need For Speed";
tab[64] = "Tom Clancy's Rainbow Six Siege";
tab[65] = "Among Us";
tab[66] = "Tomb Rider";
tab[67] = "Warcraft III";
tab[68] = "World of Warcraft ";
tab[69] = "The Sims";
tab[70] = "Spaghetti";
tab[71] = "Filet z Dorsza";
tab[72] = "Lasagne";
tab[73] = "Śledź w śmietanie";
tab[74] = "Enchiladas";
tab[75] = "Bigos";
tab[76] = "pierogi";
tab[77] = "Hamburger";
tab[78] = "zupa pomidorowa";
tab[79] = "Pizza";
tab[80] = "Afganistan";
tab[81] = "Albania";
tab[82] = "Polska";
tab[83] = "Argentyna";
tab[84] = "Belgia";
tab[85] = "Brazylia";
tab[86] = "Chiny";
tab[87] = "Japonia";
tab[88] = "Korea Południowa";
tab[89] = "Francja";
tab[90] = "Niemcy";
tab[91] = "Czechy";
tab[92] = "Ukraina";
tab[93] = "Madagaskar";
tab[94] = "Maroko";
tab[95] = "Portugalia";
tab[96] = "Serbia";
tab[97] = "Szwajcaria";
tab[98] = "Włochy";
tab[99] = "Turcja";

const kat = new Array(9);
kat[0] = "Związki frazeologiczne";
kat[1] = "Sport";
kat[2] = "Zwierzeta";
kat[3] = "Marki ubrań";
kat[4] = "Marki Samochodów";
kat[5] = "Elektronika";
kat[6] = "Gry";
kat[7] = "Dania";
kat[8] = "Panstwa";

function choose_kat(){

    switch(choose_number){
        case 1: ;
        case 2: ;
        case 3: ;
        case 4: ;
        case 5: ;
        case 6: ;
        case 7: ;
        case 8: ;
        case 9: ;
        case 10: return kat[0]; break;
        case 11: ;
        case 12: ;
        case 13: ;
        case 14: ;
        case 15: ;
        case 16: ;
        case 17: ;
        case 18: ;
        case 19: ;
        case 20: return kat[1]; break;
        case 21: ;
        case 22: ;
        case 23: ;
        case 24: ;
        case 25: ;
        case 26: ;
        case 27: ;
        case 28: ;
        case 29: ;
        case 30: return kat[2]; break;
        case 31: ;
        case 32: ;
        case 33: ;
        case 34: ;
        case 35: ;
        case 36: ;
        case 37: ;
        case 38: ;
        case 39: ;
        case 40: return kat[3]; break;
        case 41: ;
        case 42: ;
        case 43: ;
        case 44: ;
        case 45: ;
        case 46: ;
        case 47: ;
        case 48: ;
        case 49: ;
        case 50: return kat[4]; break;
        case 51: ;
        case 52: ;
        case 53: ;
        case 54: ;
        case 55: ;
        case 56: ;
        case 57: ;
        case 58: ;
        case 59: ;
        case 60: return kat[5]; break;
        case 61: ;
        case 62: ;
        case 63: ;
        case 64: ;
        case 65: ;
        case 66: ;
        case 67: ;
        case 68: ;
        case 69: ;
        case 70: return kat[6]; break;
        case 71: ;
        case 72: ;
        case 73: ;
        case 74: ;
        case 75: ;
        case 76: ;
        case 77: ;
        case 78: ;
        case 79: ;
        case 80: return kat[7]; break;
        case 81: ;
        case 82: ;
        case 83: ;
        case 84: ;
        case 85: ;
        case 86: ;
        case 87: ;
        case 88: ;
        case 89: ;
        case 90: ;
        case 91: ;
        case 92: ;
        case 93: ;
        case 94: ;
        case 95: ;
        case 96: ;
        case 97: ;
        case 98: ;
        case 99: ;
        case 99: return kat[8]; break;
    }

}

function choose(){

    switch(choose_number){
        case 1: return tab[0]; break;
        case 2: return tab[1]; break;
        case 3: return tab[2]; break;
        case 4: return tab[3]; break;
        case 5: return tab[4]; break;
        case 6: return tab[5]; break;
        case 7: return tab[6]; break;
        case 8: return tab[7]; break;
        case 9: return tab[8]; break;
        case 10: return tab[9]; break;
        case 11: return tab[10]; break;
        case 12: return tab[11]; break;
        case 13: return tab[12]; break;
        case 14: return tab[13]; break;
        case 15: return tab[14]; break;
        case 16: return tab[15]; break;
        case 17: return tab[16]; break;
        case 18: return tab[17]; break;
        case 19: return tab[18]; break;
        case 20: return tab[19]; break;
        case 21: return tab[20]; break;
        case 22: return tab[21]; break;
        case 23: return tab[22]; break;
        case 24: return tab[23]; break;
        case 25: return tab[24]; break;
        case 26: return tab[25]; break;
        case 27: return tab[26]; break;
        case 28: return tab[27]; break;
        case 29: return tab[28]; break;
        case 30: return tab[29]; break;
        case 31: return tab[30]; break;
        case 32: return tab[31]; break;
        case 33: return tab[32]; break;
        case 34: return tab[33]; break;
        case 35: return tab[34]; break;
        case 36: return tab[35]; break;
        case 37: return tab[36]; break;
        case 38: return tab[37]; break;
        case 39: return tab[38]; break;
        case 40: return tab[39]; break;
        case 41: return tab[40]; break;
        case 42: return tab[41]; break;
        case 43: return tab[42]; break;
        case 44: return tab[43]; break;
        case 45: return tab[44]; break;
        case 46: return tab[45]; break;
        case 47: return tab[46]; break;
        case 48: return tab[47]; break;
        case 49: return tab[48]; break;
        case 50: return tab[49]; break;
        case 51: return tab[50]; break;
        case 52: return tab[51]; break;
        case 53: return tab[52]; break;
        case 54: return tab[53]; break;
        case 55: return tab[54]; break;
        case 56: return tab[55]; break;
        case 57: return tab[56]; break;
        case 58: return tab[57]; break;
        case 59: return tab[58]; break;
        case 60: return tab[59]; break;
        case 61: return tab[60]; break;
        case 62: return tab[61]; break;
        case 63: return tab[62]; break;
        case 64: return tab[63]; break;
        case 65: return tab[64]; break;
        case 66: return tab[65]; break;
        case 67: return tab[66]; break;
        case 68: return tab[67]; break;
        case 69: return tab[68]; break;
        case 70: return tab[69]; break;
        case 71: return tab[70]; break;
        case 72: return tab[71]; break;
        case 73: return tab[72]; break;
        case 74: return tab[73]; break;
        case 75: return tab[74]; break;
        case 76: return tab[75]; break;
        case 77: return tab[76]; break;
        case 78: return tab[77]; break;
        case 79: return tab[78]; break;
        case 80: return tab[79]; break;
        case 81: return tab[80]; break;
        case 82: return tab[81]; break;
        case 83: return tab[82]; break;
        case 84: return tab[83]; break;
        case 85: return tab[84]; break;
        case 86: return tab[85]; break;
        case 87: return tab[86]; break;
        case 88: return tab[87]; break;
        case 89: return tab[88]; break;
        case 90: return tab[89]; break;
        case 91: return tab[90]; break;
        case 92: return tab[91]; break;
        case 93: return tab[92]; break;
        case 94: return tab[93]; break;
        case 95: return tab[94]; break;
        case 96: return tab[95]; break;
        case 97: return tab[96]; break;
        case 98: return tab[97]; break;
        case 99: return tab[98]; break;
        case 100: return tab[99]; break;
    }

}

let kategoria = choose_kat();
kategoria = kategoria.toUpperCase();
let pusta_kat = "";

pusta_kat = kategoria;

function wypisz_kat(){
    let k = document.getElementById("kategoria");
    k.innerHTML = pusta_kat;
}

let haslo = choose();
haslo = haslo.toUpperCase();

const dlugosc = haslo.length;
let ile_skuch = 10;



let haslo1 = "";

for (i=0; i<dlugosc; i++)
{
	if (haslo.charAt(i)==" ") haslo1 = haslo1 + " ";
	else haslo1 = haslo1 + "-";
}

function wypisz_haslo()
{
	document.getElementById("plansza").innerHTML = haslo1;
}

window.onload = start;

const litery = new Array(35);

litery[0] = "A";
litery[1] = "Ą";
litery[2] = "B";
litery[3] = "C";
litery[4] = "Ć";
litery[5] = "D";
litery[6] = "E";
litery[7] = "Ę";
litery[8] = "F";
litery[9] = "G";
litery[10] = "H";
litery[11] = "I";
litery[12] = "J";
litery[13] = "K";
litery[14] = "L";
litery[15] = "Ł";
litery[16] = "M";
litery[17] = "N";
litery[18] = "Ń";
litery[19] = "O";
litery[20] = "Ó";
litery[21] = "P";
litery[22] = "Q";
litery[23] = "R";
litery[24] = "S";
litery[25] = "Ś";
litery[26] = "T";
litery[27] = "U";
litery[28] = "V";
litery[29] = "W";
litery[30] = "X";
litery[31] = "Y";
litery[32] = "Z";
litery[33] = "Ż";
litery[34] = "Ź";



function start()
{
	
	let tresc_diva ="";
	
	for (i=0; i<=34; i++)
	{
		let element = "lit" + i;
		tresc_diva = tresc_diva + '<div class="litera" onclick="sprawdz('+i+')" id="'+element+'">'+litery[i]+'</div>';
		if ((i+1) % 7 ==0) tresc_diva = tresc_diva + '<div style="clear:both;"></div>';
	}
	
	document.getElementById("alfabet").innerHTML = tresc_diva;
	
	wypisz_kat();
	wypisz_haslo();
}

String.prototype.ustawZnak = function(miejsce, znak)
{
	if (miejsce > this.length - 1) return this.toString();
	else return this.substr(0, miejsce) + znak + this.substr(miejsce+1);
}

// Wczytanie Zdjecia
let standard_image = "assets/img/10.png";
document.getElementById("szubienica").innerHTML = '<img src="'+standard_image+'" alt="" />';

function sprawdz(nr)
{
	
	let trafiona = false;
	
	for(i=0; i<dlugosc; i++)
	{
		if (haslo.charAt(i) == litery[nr]) 
		{
			haslo1 = haslo1.ustawZnak(i,litery[nr]);
			trafiona = true;
		}
	}
	
	if(trafiona == true)
	{
		yes.play();
		let element = "lit" + nr;
		document.getElementById(element).style.color = "#00CC00";
		document.getElementById(element).style.border = "3px solid #00C000";
		document.getElementById(element).style.cursor = "default";
		
		wypisz_haslo();
	}
	else
	{
		no.play();
		let element = "lit" + nr;
		document.getElementById(element).style.color = "#C00000";
		document.getElementById(element).style.border = "3px solid #C00000";
		document.getElementById(element).style.cursor = "default";	
		document.getElementById(element).setAttribute("onclick",";");		

		//skucha
		ile_skuch--;
		let obraz = "assets/img/"+ ile_skuch + ".png";
		document.getElementById("szubienica").innerHTML = '<img src="'+obraz+'" alt="" />';
    }
	
	//wygrana
    if (haslo == haslo1)
    {
		wygrana.play();
        var czas2 = new Date();
        var czas3;
        czas3 = (czas2 - czas1)/1000;
		

        document.getElementById("alfabet").innerHTML  = "Tak jest! Podano prawidłowe hasło: "+haslo+'<br /><br />Zajeło ci to: '+czas3+' sekund.<br/> <span class="reset"            onclick="location.reload()">JESZCZE RAZ?</span>';
    }
	
	//przegrana
	if (ile_skuch <= 0)
	{
        lost.play();
		var czas2 = new Date();
        var czas3;
        czas3 = (czas2 - czas1)/1000;
	    document.getElementById("alfabet").innerHTML  = "Przegrana! Prawidłowe hasło: "+haslo+'<br /><br /> Zajeło Ci to: '+czas3+' sekund.<br /><br /><span class="reset" onclick="location.reload()">JESZCZE RAZ?</span>';
	}
}
























