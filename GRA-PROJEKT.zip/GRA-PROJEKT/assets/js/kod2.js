var czas1 = new Date();
var tab1 = new Array(100);
let choose_number1 = Math.floor(Math.random() * 100);

var yes = new Audio("assets/audio/yes.mp3");
var no = new Audio("assets/audio/no.mp3");
var lost = new Audio("assets/audio/lost.mp3");
var wygrana = new Audio("assets/audio/Jeszcze_jak.mp3");

tab1[0] = "Kula u nogi";
tab1[1] = "Jabłko niezgody";
tab1[2] = "Pięta achillesa";
tab1[3] = "złote serce";
tab1[4] = "Czarna owca";
tab1[5] = "Dziesiąta woda po kisielu";
tab1[6] = "Świecic oczyma";
tab1[7] = "Sam jak palec";
tab1[8] = "syzyfowa praca";
tab1[9] = "puszka pandory";
tab1[10] = "piłka nożna";
tab1[11] = "piłka ręczna";
tab1[12] = "koszykówka";
tab1[13] = "Badminton";
tab1[14] = "bilard";
tab1[15] = "tenis";
tab1[16] = "golf";
tab1[17] = "łyżwiarstwo";
tab1[18] = "kolarstwo";
tab1[19] = "łucznictwo";
tab1[20] = "Tygrys";
tab1[21] = "Żubr";
tab1[22] = "Chomik";
tab1[23] = "Niedźwiedź";
tab1[24] = "Świnka Morska";
tab1[25] = "Baran";
tab1[26] = "Owca";
tab1[27] = "Rekin";
tab1[28] = "Pingwin";
tab1[29] = "Wiewiórka";
tab1[30] = "Adidas";
tab1[31] = "Nike";
tab1[32] = "Calvin Klein";
tab1[33] = "Tommy Hilfiger";
tab1[34] = "Ralph Lauren";
tab1[35] = "The North Face";
tab1[36] = "Reebok";
tab1[37] = "Puma";
tab1[38] = "Vans";
tab1[39] = "Carhartt";
tab1[40] = "Volkswagen";
tab1[41] = "Audi";
tab1[42] = "Fiat";
tab1[43] = "Ford";
tab1[44] = "SAAB";
tab1[45] = "Renault";
tab1[46] = "Mercedes";
tab1[47] = "Mitsubishi";
tab1[48] = "Bugatti";
tab1[49] = "BMW";
tab1[50] = "Razer";
tab1[51] = "Asus";
tab1[52] = "Genesis";
tab1[53] = "Bloody";
tab1[54] = "Lenovo";
tab1[55] = "Huawei";
tab1[56] = "Samsung";
tab1[57] = "Intel";
tab1[58] = "MSI";
tab1[59] = "PlayStation";
tab1[60] = "League of Legends";
tab1[61] = "Minecraft";
tab1[62] = "Terraria";
tab1[63] = "Need For Speed";
tab1[64] = "Tom Clancy's Rainbow Six Siege";
tab1[65] = "Among Us";
tab1[66] = "Tomb Rider";
tab1[67] = "Warcraft III";
tab1[68] = "World of Warcraft ";
tab1[69] = "The Sims";
tab1[70] = "Spaghetti";
tab1[71] = "Filet z Dorsza";
tab1[72] = "Lasagne";
tab1[73] = "Śledź w śmietanie";
tab1[74] = "Enchiladas";
tab1[75] = "Bigos";
tab1[76] = "pierogi";
tab1[77] = "Hamburger";
tab1[78] = "zupa pomidorowa";
tab1[79] = "Pizza";
tab1[80] = "Afganistan";
tab1[81] = "Albania";
tab1[82] = "Polska";
tab1[83] = "Argentyna";
tab1[84] = "Belgia";
tab1[85] = "Brazylia";
tab1[86] = "Chiny";
tab1[87] = "Japonia";
tab1[88] = "Korea Południowa";
tab1[89] = "Francja";
tab1[90] = "Niemcy";
tab1[91] = "Czechy";
tab1[92] = "Ukraina";
tab1[93] = "Madagaskar";
tab1[94] = "Maroko";
tab1[95] = "Portugalia";
tab1[96] = "Serbia";
tab1[97] = "Szwajcaria";
tab1[98] = "Włochy";
tab1[99] = "Turcja";

const kat1 = new Array(9);
kat1[0] = "Związki frazeologiczne";
kat1[1] = "Sport";
kat1[2] = "Zwierzeta";
kat1[3] = "Marki ubrań";
kat1[4] = "Marki Samochodów";
kat1[5] = "Elektronika";
kat1[6] = "Gry";
kat1[7] = "Dania";
kat1[8] = "Panstwa";

function choose_kat(){

    switch(choose_number){
        case 1: ;
        case 2: ;
        case 3: ;
        case 4: ;
        case 5: ;
        case 6: ;
        case 7: ;
        case 8: ;
        case 9: ;
        case 10: return kat[0]; break;
        case 11: ;
        case 12: ;
        case 13: ;
        case 14: ;
        case 15: ;
        case 16: ;
        case 17: ;
        case 18: ;
        case 19: ;
        case 20: return kat[1]; break;
        case 21: ;
        case 22: ;
        case 23: ;
        case 24: ;
        case 25: ;
        case 26: ;
        case 27: ;
        case 28: ;
        case 29: ;
        case 30: return kat[2]; break;
        case 31: ;
        case 32: ;
        case 33: ;
        case 34: ;
        case 35: ;
        case 36: ;
        case 37: ;
        case 38: ;
        case 39: ;
        case 40: return kat[3]; break;
        case 41: ;
        case 42: ;
        case 43: ;
        case 44: ;
        case 45: ;
        case 46: ;
        case 47: ;
        case 48: ;
        case 49: ;
        case 50: return kat[4]; break;
        case 51: ;
        case 52: ;
        case 53: ;
        case 54: ;
        case 55: ;
        case 56: ;
        case 57: ;
        case 58: ;
        case 59: ;
        case 60: return kat[5]; break;
        case 61: ;
        case 62: ;
        case 63: ;
        case 64: ;
        case 65: ;
        case 66: ;
        case 67: ;
        case 68: ;
        case 69: ;
        case 70: return kat[6]; break;
        case 71: ;
        case 72: ;
        case 73: ;
        case 74: ;
        case 75: ;
        case 76: ;
        case 77: ;
        case 78: ;
        case 79: ;
        case 80: return kat[7]; break;
        case 81: ;
        case 82: ;
        case 83: ;
        case 84: ;
        case 85: ;
        case 86: ;
        case 87: ;
        case 88: ;
        case 89: ;
        case 90: ;
        case 91: ;
        case 92: ;
        case 93: ;
        case 94: ;
        case 95: ;
        case 96: ;
        case 97: ;
        case 98: ;
        case 99: ;
        case 99: return kat[8]; break;
    }

}

function choose(){

    switch(choose_number){
        case 1: return tab1[0]; break;
        case 2: return tab1[1]; break;
        case 3: return tab1[2]; break;
        case 4: return tab1[3]; break;
        case 5: return tab1[4]; break;
        case 6: return tab1[5]; break;
        case 7: return tab1[6]; break;
        case 8: return tab1[7]; break;
        case 9: return tab1[8]; break;
        case 10: return tab1[9]; break;
        case 11: return tab1[10]; break;
        case 12: return tab1[11]; break;
        case 13: return tab1[12]; break;
        case 14: return tab1[13]; break;
        case 15: return tab1[14]; break;
        case 16: return tab1[15]; break;
        case 17: return tab1[16]; break;
        case 18: return tab1[17]; break;
        case 19: return tab1[18]; break;
        case 20: return tab1[19]; break;
        case 21: return tab1[20]; break;
        case 22: return tab1[21]; break;
        case 23: return tab1[22]; break;
        case 24: return tab1[23]; break;
        case 25: return tab1[24]; break;
        case 26: return tab1[25]; break;
        case 27: return tab1[26]; break;
        case 28: return tab1[27]; break;
        case 29: return tab1[28]; break;
        case 30: return tab1[29]; break;
        case 31: return tab1[30]; break;
        case 32: return tab1[31]; break;
        case 33: return tab1[32]; break;
        case 34: return tab1[33]; break;
        case 35: return tab1[34]; break;
        case 36: return tab1[35]; break;
        case 37: return tab1[36]; break;
        case 38: return tab1[37]; break;
        case 39: return tab1[38]; break;
        case 40: return tab1[39]; break;
        case 41: return tab1[40]; break;
        case 42: return tab1[41]; break;
        case 43: return tab1[42]; break;
        case 44: return tab1[43]; break;
        case 45: return tab1[44]; break;
        case 46: return tab1[45]; break;
        case 47: return tab1[46]; break;
        case 48: return tab1[47]; break;
        case 49: return tab1[48]; break;
        case 50: return tab1[49]; break;
        case 51: return tab1[50]; break;
        case 52: return tab1[51]; break;
        case 53: return tab1[52]; break;
        case 54: return tab1[53]; break;
        case 55: return tab1[54]; break;
        case 56: return tab1[55]; break;
        case 57: return tab1[56]; break;
        case 58: return tab1[57]; break;
        case 59: return tab1[58]; break;
        case 60: return tab1[59]; break;
        case 61: return tab1[60]; break;
        case 62: return tab1[61]; break;
        case 63: return tab1[62]; break;
        case 64: return tab1[63]; break;
        case 65: return tab1[64]; break;
        case 66: return tab1[65]; break;
        case 67: return tab1[66]; break;
        case 68: return tab1[67]; break;
        case 69: return tab1[68]; break;
        case 70: return tab1[69]; break;
        case 71: return tab1[70]; break;
        case 72: return tab1[71]; break;
        case 73: return tab1[72]; break;
        case 74: return tab1[73]; break;
        case 75: return tab1[74]; break;
        case 76: return tab1[75]; break;
        case 77: return tab1[76]; break;
        case 78: return tab1[77]; break;
        case 79: return tab1[78]; break;
        case 80: return tab1[79]; break;
        case 81: return tab1[80]; break;
        case 82: return tab1[81]; break;
        case 83: return tab1[82]; break;
        case 84: return tab1[83]; break;
        case 85: return tab1[84]; break;
        case 86: return tab1[85]; break;
        case 87: return tab1[86]; break;
        case 88: return tab1[87]; break;
        case 89: return tab1[88]; break;
        case 90: return tab1[89]; break;
        case 91: return tab1[90]; break;
        case 92: return tab1[91]; break;
        case 93: return tab1[92]; break;
        case 94: return tab1[93]; break;
        case 95: return tab1[94]; break;
        case 96: return tab1[95]; break;
        case 97: return tab1[96]; break;
        case 98: return tab1[97]; break;
        case 99: return tab1[98]; break;
        case 100: return tab1[99]; break;
    }

}

let kategoria1 = choose_kat();
kategoria1 = kategoria1.toUpperCase();
let pusta_kat1 = "";

pusta_kat = kategoria;

function wypisz_kat(){
    let k = document.getElementById("kategoria2");
    k.innerHTML = pusta_kat;
}

let haslo2 = choose();
haslo2 = haslo2.toUpperCase();

const dlugosc1 = haslo.length;
let ile_skuch1 = 10;



let haslo3 = "";

for (i=0; i<dlugosc; i++)
{
	if (haslo.charAt(i)==" ") haslo3 = haslo3 + " ";
	else haslo3 = haslo3 + "-";
}

function wypisz_haslo()
{
	document.getElementById("plansza2").innerHTML = haslo3;
}

window.onload = start;

const litery1 = new Array(35);

litery1[0] = "A";
litery1[1] = "Ą";
litery1[2] = "B";
litery1[3] = "C";
litery1[4] = "Ć";
litery1[5] = "D";
litery1[6] = "E";
litery1[7] = "Ę";
litery1[8] = "F";
litery1[9] = "G";
litery1[10] = "H";
litery1[11] = "I";
litery1[12] = "J";
litery1[13] = "K";
litery1[14] = "L";
litery1[15] = "Ł";
litery1[16] = "M";
litery1[17] = "N";
litery1[18] = "Ń";
litery1[19] = "O";
litery1[20] = "Ó";
litery1[21] = "P";
litery1[22] = "Q";
litery1[23] = "R";
litery1[24] = "S";
litery1[25] = "Ś";
litery1[26] = "T";
litery1[27] = "U";
litery1[28] = "V";
litery1[29] = "W";
litery1[30] = "X";
litery1[31] = "Y";
litery1[32] = "Z";
litery1[33] = "Ż";
litery1[34] = "Ź";



function start()
{
	
	let tresc_diva1 ="";
	
	for (i=0; i<=34; i++)
	{
		let element = "lit" + i;
		tresc_diva1 = tresc_diva1 + '<div class="litera" onclick="sprawdz('+i+')" id="'+element+'">'+litery1[i]+'</div>';
		if ((i+1) % 7 ==0) tresc_diva1 = tresc_diva1 + '<div style="clear:both;"></div>';
	}
	
	document.getElementById("alfabet2").innerHTML = tresc_diva1;
	
	wypisz_kat();
	wypisz_haslo();
}

String.prototype.ustawZnak = function(miejsce1, znak)
{
	if (miejsce1 > this.length - 1) return this.toString();
	else return this.substr(0, miejsce1) + znak + this.substr(miejsce1+1);
}

// Wczytanie Zdjecia
let standard_image1 = "assets/img/10.png";
document.getElementById("szubienica2").innerHTML = '<img src="'+standard_image1+'" alt="" />';

function sprawdz(nr)
{
	
	let trafiona = false;
	
	for(i=0; i<dlugosc; i++)
	{
		if (haslo.charAt(i) == litery1[nr]) 
		{
			haslo3 = haslo3.ustawZnak(i,litery1[nr]);
			trafiona = true;
		}
	}
	
	if(trafiona == true)
	{
		yes.play();
		let element = "lit" + nr;
		document.getElementById(element).style.color = "#00CC00";
		document.getElementById(element).style.border = "3px solid #00C000";
		document.getElementById(element).style.cursor = "default";
		
		wypisz_haslo();
	}
	else
	{
		no.play();
		let element = "lit" + nr;
		document.getElementById(element).style.color = "#C00000";
		document.getElementById(element).style.border = "3px solid #C00000";
		document.getElementById(element).style.cursor = "default";	
		document.getElementById(element).setAttribute("onclick",";");		

		//skucha
		ile_skuch--;
		let obraz = "assets/img/"+ ile_skuch + ".png";
		document.getElementById("szubienica2").innerHTML = '<img src="'+obraz+'" alt="" />';
    }
	
	//wygrana
    if (haslo2 == haslo3)
    {
		wygrana.play();
        var czas2 = new Date();
        var czas3;
        czas3 = (czas2 - czas1)/1000;
		

        document.getElementById("alfabet2").innerHTML  = "Tak jest! Podano prawidłowe hasło: "+haslo2+'<br /><br />Zajeło ci to: '+czas3+' sekund.<br/> <span class="reset"            onclick="location.reload()">JESZCZE RAZ?</span>';
    }
	
	//przegrana
	if (ile_skuch <= 0)
	{
        lost.play();
		var czas2 = new Date();
        var czas3;
        czas3 = (czas2 - czas1)/1000;
	    document.getElementById("alfabet2").innerHTML  = "Przegrana! Prawidłowe hasło: "+haslo2+'<br /><br /> Zajeło Ci to: '+czas3+' sekund.<br /><br /><span class="reset" onclick="location.reload()">JESZCZE RAZ?</span>';
	}
}
